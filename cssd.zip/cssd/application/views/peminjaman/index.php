<a href="<?= base_url('peminjaman/add') ?>" class="btn btn-sm btn-primary my-2">Pinjam</a>
<div class="card">
	<div class="card-body">
		<table class="table table-bordered my-1 dt-responsive nowrap" id="datatable" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
			<thead>
				<th>No Pinjam</th>
				<th>Ruangan</th>
				<th>Status</th>
				<th>Tgl Pinjam</th>
				<th>Tgl Kembali</th>
				<th>Aksi</th>
			</thead>
			<tbody>
				<!-- <?php
						$list_peminjaman = $this->m_global->get_data('peminjaman')->result();
						if ($list_peminjaman) {
							foreach ($list_peminjaman as $key => $value) {
								echo '
			<tr>
				<td>' . $value->id_peminjaman . '</td>
				<td>' . $value->id_ruangan . '</td>
				<td>' . $value->status . '</td>
				<td>' . $value->tgl_pinjam . '</td>
				<td>' . $value->tgl_kembali . '</td>
				<td>';
								if ($value->status == 0) echo '<a href="' . base_url('peminjaman/add_detail/' . $value->id_peminjaman) . '">Tambah Alat</a> ';
								if ($value->status != 0 && !$value->tgl_kembali) echo '<a onclick="return confirm()" href="' . base_url('peminjaman/proses_pengembalian/' . $value->id_peminjaman) . '">Kembalikan</a> ';
								echo '<a href="' . base_url('peminjaman/add_detail/' . $value->id_peminjaman) . '">Detail</a> ';
								echo '</td>
			';
							}
						}
						?> -->
			</tbody>
		</table>
	</div>
</div>

<script>
	window.addEventListener("DOMContentLoaded", () => {
		tabel = $("#datatable").DataTable({
			dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
				"<'row'<'col-sm-12'tr>>" +
				"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
			buttons: [{
					extend: 'pageLength',
					text: "Tampilkan",
					className: 'btn-sm btn-primary',
				},
				{

					text: "Reload",
					className: 'btn-sm btn-success',
					action: function() {
						tabel.ajax.reload(null, false);
						toastr.success("Berhasil memuat ulang data.", "Informasi", {
							showMethod: "slideDown",
							hideMethod: "slideUp",
							timeOut: 1500,
						});
					}
				},

			],
			processing: true,
			responsive: true,
			serverSide: true,
			ajax: {
				url: `${base_url}peminjaman/get_dt_peminjaman`,
				type: "POST"
			},
			language: {
				url: `${base_url}public/assets/lang.json`

			},
			columns: [{
					data: "no",
					render: function(data, type, row, meta) {
						return meta.row + meta.settings._iDisplayStart + 1;
					}
				},
				{
					data: "nama_ruangan"
				},
				{
					data: "status"
				},
				{
					data: "tgl_pinjam"
				},
				{
					data: "tgl_kembali"
				},
				{
					data: "aksi"
				},
			],
		})

		pengembalian = (id_peminjaman) => {
			let url = `${base_url}peminjaman/proses_pengembalian/${id_peminjaman}`
			Swal.fire({
				icon: 'question',
				title: 'Apakah anda akan mengembalikan alat ini?',
				customClass: {
					confirmButton: "btn btn-success",
					cancelButton: "btn btn-dark",
				},
				showCancelButton: true,
				confirmButtonText: `Ya, kembalikan`,
				cancelButtonText: `Batal`,
			}).then(async (result) => {
				if (result.isConfirmed) {
					const response = await request_xhr(url);
					console.log(response.pesan);
					if (response.status) {
						Swal.fire({
							icon: "success",
							title: `${response.pesan}`,
							showConfirmButton: false,
							timer: 1500,
						});
						tabel.ajax.reload(null, false);
					} else {
						Swal.fire({
							icon: "warning",
							title: `${response.pesan}`,
							showConfirmButton: false,
							timer: 3500,
						});
						tabel.ajax.reload(null, false);
					}
				}
			})
		}
	})
</script>
