<div class="col">
	<div class="card my-1">
		<div class="card-header  bg-primary">
			<div class="d-flex justify-content-between">
				<h5 class=" text-white">DETAIL PEMINJAMAN</h5>
				<button type="button" class="btn btn-sm btn-light" onclick="window.history.back()">Kembali</button>
			</div>
		</div>
		<div class="card-body border border-primary">
			<div class="row">
				<div class="col-md-2">Nama Ruangan</div>
				<div class="col-md-9"><?= $peminjaman->nama_ruangan ?></div>
			</div>
			<div class="row">
				<div class="col-md-2">Status</div>
				<div class="col-md-9"><?= ($peminjaman->status == 0) ? "<span class='badge badge-warning'>Diproses</span>" : (($peminjaman->status == 1) ? "<span class='badge badge-success'>Dipinjam</span>" : "<span class='badge badge-primary'>Dikembalikan</span>") ?></div>
			</div>
			<div class="row">
				<div class="col-md-2">Tanggal Pinjam</div>
				<div class="col-md-9"><?= (!empty($peminjaman->tgl_pinjam)) ? $peminjaman->tgl_pinjam : "-" ?></div>
			</div>
			<div class="row">
				<div class="col-md-2">Tanggal Kembali</div>
				<div class="col-md-9"><?= (!empty($peminjaman->tgl_kembali)) ? $peminjaman->tgl_kembali : "-" ?></div>
			</div>
		</div>
	</div>
	<?php if ($peminjaman->status == 0 && $id_barang == 0) { ?>
		<script type="text/javascript" src="<?= base_url("public/assets/webcodecam/") ?>js/qrcodelib.js"></script>
		<script type="text/javascript" src="<?= base_url("public/assets/webcodecam/") ?>js/webcodecamjquery.js"></script>
		<h6 class="text-center mt-3">Arahkan kode QR ke kamera</h6>
		<div class="d-flex row justify-content-center">

			<div class="col-md-12 text-center">
				<canvas style="border:1px solid #000000;"></canvas>
			</div>

			<div class="col-md-6">
				<select class="form-control mt-2 " id="kamera"></select>
			</div>

		</div>
		<div class="row my-2">
			<div class="col">
				<div class="input-group mb-3">
					<select name="id_barang_temp" id="id_barang_temp" class="form-control" required>
						<option value="">- Pilih Alat -</option>
						<?php foreach ($barang as $v) { ?>
							<option value="<?= $v->id_barang; ?>"><?= $v->nama_barang; ?></option>
						<?php } ?>
					</select>
					<!-- <input type="number" class="form-control" id="id_barang_temp" placeholder="ID Barang"> -->
					<div class="input-group-append">
						<button class="btn btn-success" type="button" onclick="add_barang_temp()">add</button>
					</div>
				</div>
			</div>
		</div>
		<script>
			var arg = {
				resultFunction: function(result) {
					var id_barang_temp = result.code
					var id_peminjaman = '<?= $id_peminjaman ?>';
					location.href = "<?= base_url('peminjaman/add_detail_temp/'); ?>" + id_peminjaman + '/' + id_barang_temp
				}
			};

			var decoder = $("canvas").WebCodeCamJQuery(arg).data().plugin_WebCodeCamJQuery;
			decoder.buildSelectMenu("#kamera");
			decoder.play();
			$('select').on('change', function() {
				decoder.stop().play();
			});

			// jquery extend function
			//CONFIGURASI CAMERA
			decoder.options.zoom = 0;
			decoder.options.flipHorizontal = true;
		</script>
	<?php } ?>
	<div class="card my-4">
		<div class="card-header bg-warning">
			<b>DAFTAR ALAT YANG DIPINJAM</b>
		</div>
		<div class="card-body border border-warning">
			<table class="table table-bordered dt-responsive compact my-1" style="border-collapse: collapse; border-spacing: 0; width: 100%;" id="add_detail">
				<thead>
					<th>Nama Barang</th>
					<th width="20%">Qty</th>

					<th>Aksi</th>
				</thead>
				<tbody>
					<?php if ($id_barang != 0) {
						$detail_barang = $this->m_global->get_data('barang', ['id_barang' => $id_barang])->row();
					?>

						<tr>
							<td><?= $detail_barang->nama_barang; ?></td>
							<td>
								<div class="input-group">
									<div class="input-group-prepend">
										<button class="btn btn-danger btn-min" type="button">-</button>
									</div>
									<input type="text" class="form-control" name="stok" id="stok" value="1" min="0" max="<?= $detail_barang->stok_tersedia; ?>" readonly required>
									<div class="input-group-append">
										<button class="btn btn-danger btn-plus" type="button">+</button>
									</div>
								</div>
							</td>
							<td><button class="btn btn-success" onclick="add_peminjaman_detail('<?= $detail_barang->id_barang; ?>')">Tambah</button></td>
						</tr>
						<?php }
					$peminjaman_detail = $this->m_global->get_data('peminjaman_detail a', ['a.id_peminjaman' => $id_peminjaman], ['table' => 'barang b', 'cond' => 'a.id_barang=b.id_barang', 'type' => 'left'])->result();
					if ($peminjaman_detail) {
						foreach ($peminjaman_detail as $key => $value) { ?>

							<tr>
								<td><?= $value->nama_barang; ?></td>
								<td><?= $value->qty; ?></td>
								<?php if ($peminjaman->status == 0) { ?>
									<td><button class="btn btn-sm btn-danger" type="button" onclick="hapus_barang('<?= $id_peminjaman; ?>')">Hapus</button></td>
								<?php } else { ?>
									<td>-</td>
								<?php } ?>
							</tr>


					<?php }
					} ?>
				</tbody>
			</table>
			<?php if ($peminjaman_detail && $peminjaman->status == 0) { ?>
				<a href="#" onclick="proses_peminjaman(<?= $id_peminjaman; ?>)" class="btn btn-block btn-lg btn-primary my-1">Proses Pinjam</a>
			<?php } ?>
		</div>
	</div>


</div>
<script>
	window.addEventListener("DOMContentLoaded", () => {
		$("#add_detail").DataTable({
			bInfo: false,
			searching: false,
			paginate: false,
			responsive: true
		});
	})

	let hapus_barang = (id_peminjaman) => {
		let url = `${base_url}peminjaman/hapus_barang_peminjaman/${id_peminjaman}`;
		Swal.fire({
			icon: "question",
			title: "Apakah anda yakin akan menghapus data ini?",
			customClass: {
				confirmButton: "btn btn-success",
				cancelButton: "btn btn-dark",

			},
			showCancelButton: true,
			confirmButtonText: "Ya, Hapus",
			cancelButtonText: "Batal"
		}).then(
			async (result) => {
				if (result.isConfirmed) {
					const response = await request_xhr(url);
					console.log(response.pesan);
					if (response.status) {
						Swal.fire({
							icon: "success",
							title: `${response.pesan}`,
							showConfirmButton: false,
							timer: 1500,
						});
						location.href = `${base_url}peminjaman/add_detail/${id_peminjaman}`;
					} else {
						Swal.fire({
							icon: "warning",
							title: `${response.pesan}`,
							showConfirmButton: false,
							timer: 3500,
						});
						location.href = `${base_url}peminjaman/add_detail/${id_peminjaman}`;
					}
				}
			}
		)
	}

	function add_barang_temp() {
		var id_barang_temp = document.getElementById('id_barang_temp').value
		var id_peminjaman = '<?= $id_peminjaman ?>';
		location.href = "<?= base_url('peminjaman/add_detail_temp/'); ?>" + id_peminjaman + '/' + id_barang_temp
	}

	function add_peminjaman_detail(id_barang) {
		var id_barang = id_barang
		var qty = document.getElementById('stok').value
		var id_peminjaman = '<?= $id_peminjaman ?>';
		location.href = "<?= base_url('peminjaman/add_peminjaman_detail/'); ?>" + id_peminjaman + '/' + id_barang + '/' + qty
	}

	proses_peminjaman = (id_peminjaman) => {
		let url = `${base_url}peminjaman/proses_peminjaman/${id_peminjaman}`
		Swal.fire({
			icon: 'question',
			title: 'Apakah anda akan meminjam alat ini?',
			customClass: {
				confirmButton: "btn btn-success",
				cancelButton: "btn btn-dark",
			},
			showCancelButton: true,
			confirmButtonText: `Ya, pinjam`,
			cancelButtonText: `Batal`,
		}).then(async (result) => {
			if (result.isConfirmed) {
				const response = await request_xhr(url);
				console.log(response.pesan);
				if (response.status) {
					Swal.fire({
						icon: "success",
						title: `${response.pesan}`,
						showConfirmButton: false,
						timer: 1500,
					});
					location.href = `${base_url}peminjaman`;
				} else {
					Swal.fire({
						icon: "warning",
						title: `${response.pesan}`,
						showConfirmButton: false,
						timer: 3500,
					});
					location.href = `${base_url}peminjaman`;
				}
			}
		})
	}

	document.querySelector(".btn-plus").addEventListener("click", () => {
		let jml = Number(document.querySelector('#stok').value)
		let maks_stok = document.getElementById("stok").max;
		if (jml >= maks_stok) {
			document.querySelector('#stok').value = maks_stok
		} else {
			document.querySelector('#stok').value = parseInt(document.querySelector('#stok').value) + 1;
		}
	})
	document.querySelector(".btn-min").addEventListener("click", () => {
		if (document.querySelector('#stok').value > 2) {
			document.querySelector('#stok').value = parseInt(document.querySelector('#stok').value) - 1;
		} else {
			document.querySelector('#stok').value = 1;
		}
	})
</script>
