<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-body">
				<div class="d-flex justify-content-center">
					<center>
						<h3><i class="ri ri-hospital-line"></i></h3>
						<h4>Selamat Datang di Sistem Pencatatan Alat CSSD</h4>
					</center>
				</div>
			</div>


		</div>
	</div>
</div>
