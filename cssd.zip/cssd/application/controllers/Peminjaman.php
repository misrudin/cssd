<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Peminjaman extends CI_Controller
{

	public function index()
	{
		$data['title'] = 'Peminjaman';
		$data['view'] = 'peminjaman/index';
		$data['ruangan'] = $this->m_global->get_data('ruangan')->result();
		$data['barang'] = $this->m_global->get_data('barang')->result();
		$this->load->view('lyt/index', $data);
	}

	public function get_dt_peminjaman()
	{
		$this->load->model('m_dt_peminjaman');
		$list = $this->m_dt_peminjaman->get_datatables();
		$data = array();
		foreach ($list as $key) {
			$row = array();
			$row['no'] = null;
			$row['nama_ruangan'] = $key->nama_ruangan;
			$row['status'] = ($key->status == 0) ? "<span class='badge badge-warning'>Diproses</span>" : (($key->status == 1) ? "<span class='badge badge-success'>Dipinjam</span>" : "<span class='badge badge-primary'>Dikembalikan</span>");
			$row['tgl_pinjam'] = (!empty($key->tgl_pinjam)) ? tgl_indo($key->tgl_pinjam) : "-";
			$row['tgl_kembali'] = (!empty($key->tgl_kembali)) ? tgl_indo($key->tgl_kembali) : "-";
			$row["aksi"] 	  = ($key->status == 0) ? "<a class='btn btn-sm btn-primary' href=" . base_url('peminjaman/add_detail/' . $key->id_peminjaman) . ">Tambah Alat</a>" : (($key->status != 0 && !$key->tgl_kembali) ? "<a class='btn btn-sm btn-success' onclick='pengembalian(" . $key->id_peminjaman . ")' href='#'>Kembalikan</a> <a class='btn btn-sm btn-danger' href=" . base_url('peminjaman/add_detail/' . $key->id_peminjaman) . ">Detail</a>" : (($key->status == 2 && $key->tgl_kembali) ? "<a class='btn btn-sm btn-danger' href=" . base_url('peminjaman/add_detail/' . $key->id_peminjaman) . ">Detail</a>" : ""));

			$data[]   = $row;
		}
		$output = array(
			"draw"          => $_POST['draw'],
			"recordsTotal"  => $this->m_dt_peminjaman->count_all(),
			"recordsFiltered" => $this->m_dt_peminjaman->count_filtered(),
			"data"          => $data,
		);

		echo json_encode($output);
	}

	function add()
	{
		$data['title'] = 'Buat Peminjaman';
		$data['view'] = 'peminjaman/add';
		$data['ruangan'] = $this->m_global->get_data('ruangan')->result();
		//$data['barang'] = $this->m_global->get_data('barang')->result();
		$this->load->view('lyt/index', $data);
	}

	function simpan_peminjaman()
	{
		$data = array(
			'id_ruangan' => $this->input->post('id_ruangan')
		);
		$this->m_global->simpan_data('peminjaman', $data);
		$id_peminjaman = $this->db->insert_id();

		redirect('peminjaman/add_detail/' . $id_peminjaman);
	}

	function proses_peminjaman($id_peminjaman)
	{
		$peminjaman = $this->m_global->get_data('peminjaman', ['id_peminjaman' => $id_peminjaman])->row();
		if ($peminjaman) {
			if ($peminjaman->status == 0) {


				$data = [
					'status' => 1,
					'tgl_pinjam' => date("Y-m-d")
				];
				$qry_update_peminjaman = $this->m_global->update_data('peminjaman', $data, ['id_peminjaman' => $id_peminjaman]);
				//update tbl peminjaman
				//update tbl barang
				$peminjaman_detail = $this->m_global->get_data('peminjaman_detail', ['id_peminjaman' => $id_peminjaman])->result();
				if ($peminjaman_detail) {
					foreach ($peminjaman_detail as $key => $value) {
						$this->db->set('stok_tersedia', 'stok_tersedia-' . $value->qty, FALSE);
						$this->db->where('id_barang', $value->id_barang);
						$qry_update_barang = $this->db->update('barang');
					}
				}
			}
		}
		if ($qry_update_peminjaman && $qry_update_barang) {
			$json['pesan'] = 'Berhasil meminjam alat';
			$json['id'] = $id_peminjaman;
			$json['status'] = true;
		} else {
			$json['pesan'] = 'Gagal meminjam alat';
			$json['status'] = false;
		}
		$this->output->set_content_type('application/json')->set_output(json_encode($json));
	}
	function proses_pengembalian($id_peminjaman)
	{
		$peminjaman = $this->m_global->get_data('peminjaman', ['id_peminjaman' => $id_peminjaman])->row();
		if ($peminjaman) {
			if ($peminjaman->status == 1) {


				$data = [
					'status' => 2,
					'tgl_kembali' => date("Y-m-d")
				];
				$qry_update_peminjaman = $this->m_global->update_data('peminjaman', $data, ['id_peminjaman' => $id_peminjaman]);
				//update tbl peminjaman
				//update tbl barang
				$peminjaman_detail = $this->m_global->get_data('peminjaman_detail', ['id_peminjaman' => $id_peminjaman])->result();
				if ($peminjaman_detail) {
					foreach ($peminjaman_detail as $key => $value) {
						$this->db->set('stok_tersedia', 'stok_tersedia+' . $value->qty, FALSE);
						$this->db->where('id_barang', $value->id_barang);
						$qry_update_barang = $this->db->update('barang');
					}
				}
			}
		}
		if ($qry_update_peminjaman && $qry_update_barang) {
			$json['pesan'] = 'Berhasil mengembalikan alat';
			$json['status'] = true;
		} else {
			$json['pesan'] = 'Gagal mengembalikan alat';
			$json['status'] = false;
		}
		$this->output->set_content_type('application/json')->set_output(json_encode($json));
	}

	function add_detail($id_peminjaman, $id_barang = null)
	{
		$data['id_barang'] = ($id_barang) ?: 0;
		$data['id_peminjaman'] = $id_peminjaman;
		$data['barang'] = $this->m_global->get_data('barang')->result();
		$data['title'] = 'Buat Peminjaman';
		$data['view'] = 'peminjaman/add_detail';
		$data['peminjaman'] = $this->m_global->get_data('peminjaman a', ['a.id_peminjaman' => $id_peminjaman], ['table' => 'ruangan b', 'cond' => 'a.id_ruangan=b.id_ruangan', 'type' => 'left'])->row();
		//$data['barang'] = $this->m_global->get_data('barang')->result();
		$this->load->view('lyt/index', $data);
	}

	function add_detail_temp($id_peminjaman, $id_barang)
	{
		$cek_pinjam = $this->m_global->get_data('peminjaman_detail', ['id_peminjaman' => $id_peminjaman, 'id_barang' => $id_barang])->row();

		if ($cek_pinjam) {
			$this->m_global->ntf_swal('error', "Alat sudah dipinjam");
			redirect('peminjaman/add_detail/' . $id_peminjaman);
		} else {
			$cek_id_barang = $this->m_global->get_data('barang', ['id_barang' => $id_barang])->row();
			$cek_id_peminjaman = $this->m_global->get_data('peminjaman', ['id_peminjaman' => $id_peminjaman])->row();
			if ($cek_id_barang && $cek_id_peminjaman) {
				redirect('peminjaman/add_detail/' . $id_peminjaman . '/' . $id_barang);
			} else {
				redirect('peminjaman/add_detail/' . $id_peminjaman);
			}
		}
	}

	function add_peminjaman_detail($id_peminjaman, $id_barang, $qty)
	{
		$data = array(
			'id_peminjaman' => $id_peminjaman,
			'id_barang' => $id_barang,
			'qty' => $qty,
		);
		$cek_pinjam = $this->m_global->get_data('peminjaman_detail', ['id_peminjaman' => $id_peminjaman, 'id_barang' => $id_barang])->row();
		if (!$cek_pinjam) {
			$query = $this->m_global->simpan_data('peminjaman_detail', $data);
			if ($query) {
				$this->m_global->ntf_swal('success', "Berhasil simpan data");
			} else {
				$this->m_global->ntf_swal('error', "Gagal simpan data");
			}
		} else {
			$this->m_global->ntf_swal('error', "Alat sudah dipinjam");
		}
		redirect('peminjaman/add_detail/' . $id_peminjaman);
	}

	public function coba()
	{
		$cek_update = $this->m_global->get_data('barang', ['id_barang' => 3])->row();
		$data_update = ['stok' => intval($cek_update->stok) - intval(3)];
		echo json_encode($data_update);
	}

	public function pinjam()
	{
		$data = [
			'id_barang' => $this->input->post('id_barang'),
			'id_ruangan' => $this->input->post('id_ruangan'),
			'jumlah' => $this->input->post('qty'),
			'tgl_pinjam' => date('Y-m-d'),
			'tgl_kembali' => date('Y-m-d'),
			'status' => 'P'
		];

		$query = $this->m_global->simpan_data('peminjaman', $data);

		$cek_update = $this->m_global->get_data('barang', ['id_barang' => $data['id_barang']])->row();
		$data_update['stok'] = intval($cek_update->stok) - intval($data['jumlah']);
		$query_update = $this->m_global->update_data('barang', $data_update, ['id_barang' => $data['id_barang']]);

		if ($query && $query_update) {
			$json['status'] = true;
			$json['pesan'] = "Berhasil meminjam ";
		} else {
			$json['status'] = false;
			$json['pesan'] = "Gagal meminjam ";
		}
		$this->output->set_content_type('application/json')->set_output(json_encode($json));
	}

	public function hapus_barang_peminjaman($id_peminjaman)
	{
		$query = $this->m_global->hapus_data('peminjaman_detail', ['id_peminjaman' => $id_peminjaman]);
		if ($query) {
			$json['status'] = true;
			$json['pesan'] = "Berhasil menghapus data ";
		} else {
			$json['status'] = false;
			$json['pesan'] = "Gagal menghapus data ";
		}

		$this->output->set_content_type('application/json')->set_output(json_encode($json));
	}
}

/* End of file Peminjaman.php */
